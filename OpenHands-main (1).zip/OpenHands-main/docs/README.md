# Setup

```
npm install -g mint
```

or

```
yarn global add mint
```

# Preview

```
mint dev
```
