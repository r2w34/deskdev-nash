def string_length(s):
    return len(s)
