def to_lowercase(s):
    return s.lower()
