---
name: Feature Request or Enhancement
about: Suggest an idea for an OpenHands feature or enhancement
title: ''
labels: 'enhancement'
assignees: ''

---

**What problem or use case are you trying to solve?**

**Describe the UX or technical implementation you have in mind**

**Additional context**


### If you find this feature request or enhancement useful, make sure to add a 👍 to the issue
